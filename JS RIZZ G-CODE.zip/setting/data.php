<?php 
$nik = "WEB RIZZ | ULTIMATE | UY";
$sender = "support@Rizzultimate.co";
?>